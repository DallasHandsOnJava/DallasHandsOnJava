package org.mzb.soccermanager

import org.slf4j.*
import groovy.util.logging.Slf4j;

import javax.swing.JComponent;
import javax.swing.JLabel
import javax.swing.JOptionPane
import javax.swing.JTextField

@Slf4j
class PlayerDialog {
	
	def createTeam() {
		def team = new Team()
		team.name = JOptionPane.showInputDialog("What is your team's name?")
		int nPlayers = JOptionPane.showInputDialog("How many players are on your team?").toInteger()
		
		log.error "nPlayers: $nPlayers"
		
		def fields = [firstName: new JTextField(), lastName: new JTextField(), jerseyNumber: new JTextField(),
				emailAddress: new JTextField(), phoneNumber: new JTextField()]

		def inputs = fields.inject([]) {list, name, field->
			list << new JLabel(name)
			list << field
		} as JComponent[]
				
		(1..nPlayers).each{
			JOptionPane.showMessageDialog(null, inputs, "My custom dialog", JOptionPane.PLAIN_MESSAGE)
			team.players << new Player(firstName: fields.firstName, lastName: fields.lastName,
					jerseyNumber: fields.jerseyNumber, emailAddress: fields.emailAddress,
					phoneNumber: fields.phoneNumber)
		}
		
		log.error team.toString()
	}
	
	public static void main(String[] args) {
		new PlayerDialog().createTeam()
	}
}
