package org.mzb.soccermanager

class Player {
	def firstName
	def lastName
	def jerseyNumber
	def emailAddress
	def phoneNumber
	
	String toString() {
		return """\
firstName: $firstName.text
lastName: $lastName.text
jerseyNumber: $jerseyNumber.text
emailAddres: $emailAddress.text
phoneNumber: $phoneNumber.text
"""
	}
}
