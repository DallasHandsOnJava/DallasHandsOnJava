package org.mzb.soccermanager

class Team {
	def name
	def players = []
	
	String toString() {
		return "name: $name\n" + players.collect{it.toString()}.join("\n")
	}
}
