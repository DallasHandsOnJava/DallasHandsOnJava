package org.mzbrand.gradle

import org.gradle.api.Plugin
import org.gradle.api.Project;

class CommonPlugin implements Plugin<Project> {

	@Override
	public void apply(Project target) {
		// All projects that import this plugin will include the logback and slf4j 
		// libraries in their compile and runtime classpaths
		target.apply plugin: 'groovy'
		
		target.dependencies {
			groovy group: 'org.codehaus.groovy', name: 'groovy', version: '1.8.6'
			
			compile group: "ch.qos.logback", name: "logback-classic", 
					version: target.hasProperty('logbackVersion') ? target.logbackVersion : '1.0.1'
			compile group: "org.slf4j", name: "slf4j-api", 
					version: target.hasProperty('slf4jVersion') ? target.slf4jVersion : '1.6.4'
		}	
	}
}
